/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.model;

/**
 *
 * @author PHUC HIEP
 */
public class Customer {
    private Integer customerID;
    private String fullName;
    private String email;
    private String phone;
    private String identifyNumber;

    public Customer() {
    }

    public Customer(Integer customerID, String fullName, String email, String phone, String identifyNumber) {
        this.customerID = customerID;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.identifyNumber = identifyNumber;
    }

    public Customer(String fullName, String email, String phone, String identifyNumber) {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.identifyNumber = identifyNumber;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        if(customerID == null){
            throw new IllegalArgumentException("CustomerID khong duoc de trong");
        }
        this.customerID = customerID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        if(fullName.isEmpty() || fullName.equals("")){
            throw new IllegalArgumentException("Ten khach hang khong duoc de trong");
        }
        this.fullName = fullName;
        
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdentifyNumber() {
        return identifyNumber;
    }

    public void setIdentifyNumber(String identifyNumber) {
        this.identifyNumber = identifyNumber;
    }
    
    
}
