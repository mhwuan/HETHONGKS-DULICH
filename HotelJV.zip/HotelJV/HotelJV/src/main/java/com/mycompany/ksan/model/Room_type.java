/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.model;

import java.math.BigDecimal;

/**
 *
 * @author PHUC HIEP
 */
public class Room_type {
    private Integer roomTypeID;
    private Integer hotelID;
    private String typeName;
    private String description;
    private Integer capacity;
    private BigDecimal basePrice;

    public Room_type() {
    }

    public Room_type(Integer roomTypeID, Integer hotelID, String typeName, String description, Integer capacity, BigDecimal basePrice) {
        this.roomTypeID = roomTypeID;
        this.hotelID = hotelID;
        this.typeName = typeName;
        this.description = description;
        this.capacity = capacity;
        this.basePrice = basePrice;
    }

    public Integer getRoomTypeID() {
        return roomTypeID;
    }

    public void setRoomTypeID(Integer roomTypeID) {
        if(roomTypeID == null){
            throw new IllegalArgumentException("RoomTypeID khong duoc de trong.");
        }else{
            this.roomTypeID = roomTypeID;
        }
    }

    public Integer getHotelID() {
        return hotelID;
    }

    public void setHotelID(Integer hotelID) {
        if(hotelID == null){
            throw new IllegalArgumentException("HotelID khong duoc de trong");
        }
        this.hotelID = hotelID;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        if(typeName.isEmpty() || typeName.equals("")){
            throw new IllegalArgumentException("TypeName khong duoc de trong");
        }
        this.typeName = typeName;
        
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        if(capacity == null){
            throw new IllegalArgumentException("So luong nguoi toi da khong duoc de trong");
        }
        this.capacity = capacity;
        
    }

    public BigDecimal getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(BigDecimal basePrice) {
        if (basePrice == null) {
            throw new IllegalArgumentException("BasePrice khong duoc de trong (null).");
        }

        BigDecimal min = new BigDecimal("0.00");
        BigDecimal max = new BigDecimal("99999999.99");

        if (basePrice.compareTo(max) > 0 || basePrice.compareTo(min) < 0) {
            throw new IllegalArgumentException("Ngoai gioi han gia.");
        }

        this.basePrice = basePrice;
    }
    
}
