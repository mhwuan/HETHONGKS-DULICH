/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.dal;

import com.mycompany.ksan.dto.RoomInformationDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class RoomInformationDAO {
    private final DBContext dbContext = new DBContext();

    public List<RoomInformationDTO> getAvailableRoomInforByHotel(int hotelId, LocalDateTime checkIn, LocalDateTime checkOut) throws SQLException {
        List<RoomInformationDTO> list = new ArrayList<>();

        // SỬA SQL: Thêm JOIN ROOM_TYPE và chọn các cột cần thiết (R.*, RT.*)
        String sql = "SELECT R.*, RT.Capacity, RT.BasePrice, RT.TYPE_NAME " + 
                     "FROM ROOM R " +
                     "JOIN ROOM_TYPE RT ON R.RoomTypeID = RT.RoomTypeID AND R.Hotel_ID = RT.Hotel_ID " + // Thêm JOIN
                     "WHERE R.Hotel_ID = ? " +
                     "AND NOT EXISTS (" +
                        "SELECT 1 FROM BOOKING_ROOM BR " +
                        "JOIN BOOKING B ON BR.BookingID = B.BookingID " +
                        "WHERE BR.RoomID = R.RoomID " +
                        "AND B.STATUS NOT IN ('Cancelled', 'CheckedOut') " +
                        "AND B.Check_Out_Date > ? " +
                        "AND B.Check_In_Date < ?" +
                     ")";

        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, hotelId);
            ps.setObject(2, checkIn);
            ps.setObject(3, checkOut);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    // SỬA LỖI MAPPING: Gọi hàm helper mới để ánh xạ sang DTO
                    RoomInformationDTO roomInfo = extractRoomInformationDTO(rs);
                    list.add(roomInfo); // Thêm DTO vào List
                }
            }

        } catch (SQLException e) {
            System.err.println("Lỗi khi tìm phòng trống (getAvailableRoomsByHotel): " + e.getMessage());
            throw e; 
        }

        return list;
    }

    // -------------------------------------------------------------------------
    // BỔ SUNG: Hàm Helper Ánh xạ DTO mới
    // -------------------------------------------------------------------------

    
    private RoomInformationDTO extractRoomInformationDTO(ResultSet rs) throws SQLException {
        RoomInformationDTO info = new RoomInformationDTO();

        // Từ bảng ROOM (R.*)
        info.setRoomId(rs.getInt("RoomID"));
        info.setRoomNumber(rs.getString("RoomNumber"));
        info.setStatus(rs.getString("STATUS"));

        // Từ bảng ROOM_TYPE (RT.*)
        info.setCapacity(rs.getInt("Capacity"));
        info.setBasePrice(rs.getBigDecimal("BasePrice"));
        info.setRoomTypeName(rs.getString("TYPE_NAME")); // Giả định tên cột trong RT là TYPE_NAME

        return info;
    }
    
    
}
