/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.model;

import java.math.BigDecimal;

/**
 *
 * @author PHUC HIEP
 */
public class BookingRoom {
    private Integer bookingID;
    private Integer customerID;
    private Integer roomID;
    private BigDecimal roomPrice;

    public BookingRoom() {
    }

    public BookingRoom(Integer bookingID, Integer customerID, Integer roomID, BigDecimal roomPrice) {
        this.bookingID = bookingID;
        this.customerID = customerID;
        this.roomID = roomID;
        this.roomPrice = roomPrice;
    }

    public Integer getBookingID() {
        return bookingID;
    }

    public void setBookingID(Integer bookingID) {
        if(bookingID == null){
            throw new IllegalArgumentException("BookingID khong duoc de trong");
        }
        this.bookingID = bookingID;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        if(customerID == null){
            throw new IllegalArgumentException("CustomerID khong duoc de trong");
        }
        this.customerID = customerID;
    }

    public Integer getRoomID() {
        return roomID;
    }

    public void setRoomID(Integer roomID) {
        if(roomID == null){
            throw new IllegalArgumentException("RoomID khong duoc de trong");
        }
        this.roomID = roomID;
    }

    public BigDecimal getRoomPrice() {
        return roomPrice;
    }

    public void setRoomPrice(BigDecimal roomPrice) {
        if (roomPrice == null) {
            throw new IllegalArgumentException("RoomPrice khong duoc de trong (null)");
        }

        BigDecimal min = new BigDecimal("0.00");
        BigDecimal max = new BigDecimal("99999999.99");

        if (roomPrice.compareTo(max) > 0 || roomPrice.compareTo(min) < 0) {
            throw new IllegalArgumentException("Ngoai gioi han gia");
        }

        this.roomPrice = roomPrice;
    }

}
