/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.dto;

import com.mycompany.ksan.model.Booking;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class BookingDTO {
    private int hotelID;
    private Booking booking;
    private List<RoomInformationDTO> room = new ArrayList<>();

   
    
    public BookingDTO() {
        this.booking = new Booking();
    }

    public BookingDTO(int hotelID, Booking booking) {
        this.hotelID = hotelID;
        this.booking = booking;
    }
    
    public int getHotelID() {
        return hotelID;
    }

    public void setHotelID(int hotelID) {
        this.hotelID = hotelID;
    }
    

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public List<RoomInformationDTO> getRoom() {
        return room;
    }

   

    public void setRoom(List<RoomInformationDTO> room) {
        this.room = room;
    }

    
}
