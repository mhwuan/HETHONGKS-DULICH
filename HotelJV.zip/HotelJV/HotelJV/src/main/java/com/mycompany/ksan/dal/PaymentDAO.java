package com.mycompany.ksan.dal;

import com.mycompany.ksan.dto.RoomInformationDTO;
import com.mycompany.ksan.model.Payment;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class PaymentDAO {
    private final DBContext dbContext;
    
    public PaymentDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private Payment extractPaymentFromResultSet(ResultSet rs) throws SQLException {
        Payment payment = new Payment();
        payment.setPaymentID(rs.getInt("PaymentID"));
        payment.setBookingID(rs.getInt("BookingID"));
        payment.setCustomerID(rs.getInt("CustomerID"));
        
        try {
            payment.setPaymentDate(rs.getObject("Payment_Date", LocalDate.class));
            payment.setPaymentMethod(rs.getString("Payment_Method"));
            payment.setAmount(rs.getBigDecimal("Amount"));
            payment.setPaymentStatus(rs.getString("Payment_Status"));
            payment.setTransactionID(rs.getString("TransactionID"));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        return payment;
    }
    
    //Insert/Create
    public int insertPayment(Payment payment) throws SQLException {
    if (payment == null) {
            throw new IllegalArgumentException("Payment khong duoc null");
        }

        String sql = "INSERT INTO PAYMENT (BookingID, CustomerID, Payment_Date, Payment_Method, Amount, Payment_Status, TransactionID) VALUES (?, ?, ?, ?, ?, ?, ?)";

        int newPaymentID = -1;

        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, payment.getBookingID());
            ps.setInt(2, payment.getCustomerID());
            ps.setObject(3, payment.getPaymentDate());
            ps.setString(4, payment.getPaymentMethod());
            ps.setBigDecimal(5, payment.getAmount());
            ps.setString(6, payment.getPaymentStatus());
            ps.setString(7, payment.getTransactionID());

            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                try (java.sql.ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        newPaymentID = generatedKeys.getInt(1);
                    }
                }
            }

            return newPaymentID;

        } catch (SQLException e) {
            throw e;
        }
    }
    
    //Read by ID
    public Payment getPaymentByID(int paymentID) throws SQLException {
        String sql = "Select * From PAYMENT Where PaymentID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, paymentID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractPaymentFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc Payment theo ID: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    //Read All
    public List<Payment> getAllPayments() throws SQLException {
        List<Payment> paymentList = new ArrayList<>();
        String sql = "Select * From PAYMENT";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                paymentList.add(extractPaymentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc danh sach Payment: " + e.getMessage());
            throw e;
        }
        return paymentList;
    }
    
    //Update
    public boolean updatePayment(Payment payment) throws SQLException {
        if (payment == null) {
            throw new IllegalArgumentException("Payment khong duoc null");
        }
        
        String sql = "Update PAYMENT Set BookingID = ?, CustomerID = ?, Payment_Date = ?, Payment_Method = ?, Amount = ?, Payment_Status = ?, TransactionID = ? Where PaymentID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, payment.getBookingID());
            ps.setInt(2, payment.getCustomerID());
            ps.setObject(3, payment.getPaymentDate());
            ps.setString(4, payment.getPaymentMethod());
            ps.setBigDecimal(5, payment.getAmount());
            ps.setString(6, payment.getPaymentStatus());
            ps.setString(7, payment.getTransactionID());
            ps.setInt(8, payment.getPaymentID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi cap nhat Payment: " + e.getMessage());
            throw e;
        }
    }
    
    //Delete
    public boolean deletePayment(int paymentID) throws SQLException {
        String sql = "Delete From PAYMENT Where PaymentID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, paymentID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi xoa Payment: " + e.getMessage());
            throw e;
        }
    }
    
    
    //Insert by Batch
    public boolean insertBookingRoomDetailsBatch(int bookingID, int customerID, List<RoomInformationDTO> rooms) throws SQLException {
        if (rooms == null || rooms.isEmpty()) {
            throw new IllegalArgumentException("Danh sach phong khong duoc null hoac rong.");
        }

        // Câu lệnh SQL chèn vào bảng BOOKING_ROOM (BookingID, CustomerID, RoomID, RoomPrice)
        String sql = "INSERT INTO BOOKING_ROOM (BookingID, CustomerID, RoomID, RoomPrice) VALUES (?, ?, ?, ?)";

        Connection conn = null;
        try {
            conn = dbContext.getConnection();
            conn.setAutoCommit(false); // Bắt đầu Transaction

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                // Ý tưởng VÒNG LẶP của bạn: Lặp qua danh sách phòng
                for (RoomInformationDTO roomInfo : rooms) { 

                    // Lấy giá trị Price (dùng BasePrice hoặc giá cuối cùng đã tính)
                    BigDecimal priceToSave = roomInfo.getBasePrice(); 

                    // Gán tham số cho PreparedStatement
                    ps.setInt(1, bookingID);
                    ps.setInt(2, customerID);
                    ps.setInt(3, roomInfo.getRoomId());
                    ps.setBigDecimal(4, priceToSave);

                    // Thêm lệnh chèn vào batch
                    ps.addBatch(); 
                }

                // Thực thi toàn bộ Batch (chỉ gọi DB 1 lần)
                int[] results = ps.executeBatch(); 

                // Kiểm tra kết quả Batch
                for (int result : results) {
                    if (result <= 0) {
                        conn.rollback();
                        return false;
                    }
                }

                conn.commit(); // Hoàn tất transaction
                return true;
            }
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            System.err.println("Loi khi them chi tiet phong (BookingRoom): " + e.getMessage());
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }
}