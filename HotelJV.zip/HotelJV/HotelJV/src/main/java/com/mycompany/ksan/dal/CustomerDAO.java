package com.mycompany.ksan.dal;

import com.mycompany.ksan.model.Customer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class CustomerDAO {
    private final DBContext dbContext;
    
    public CustomerDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private Customer extractCustomerFromResultSet(ResultSet rs) throws SQLException {
        Customer customer = new Customer();
        customer.setCustomerID(rs.getInt("CustomerID"));
        
        try {
            customer.setFullName(rs.getString("FullName"));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        customer.setEmail(rs.getString("Email"));
        customer.setPhone(rs.getString("Phone"));
        customer.setIdentifyNumber(rs.getString("IdentifyNumber"));
        return customer;
    }
    
    //Create
    public int insertCustomer(Customer customer) throws SQLException {
        if (customer == null) {
            throw new IllegalArgumentException("Customer khong duoc null");
        }

        // --- BƯỚC 1: KIỂM TRA TRÙNG LẶP IdentifyNumber ---
        String checkSql = "SELECT COUNT(*) FROM Customer WHERE IdentifyNumber = ?";

        try (Connection conn = dbContext.getConnection();
            PreparedStatement checkPs = conn.prepareStatement(checkSql)) {

            checkPs.setString(1, customer.getIdentifyNumber());

            try (ResultSet rs = checkPs.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {

                    System.err.println("Loi: IdentifyNumber da ton tai trong he thong.");

                    throw new IllegalStateException("IdentifyNumber da ton tai.");

                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi kiem tra IdentifyNumber: " + e.getMessage());
            throw e;
        }


        // --- BƯỚC 2: THỰC HIỆN INSERT VÀ LẤY ID ---
        int customerID = 0;

        String sql = "Insert into Customer (FullName, Email, Phone, IdentifyNumber) Values (?, ?, ?, ?)";

        try (Connection conn = dbContext.getConnection();
             // <<< ĐÃ SỬA: BỔ SUNG tham số Statement.RETURN_GENERATED_KEYS >>>
             PreparedStatement ps = conn.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, customer.getFullName());
            ps.setString(2, customer.getEmail());
            ps.setString(3, customer.getPhone());
            ps.setString(4, customer.getIdentifyNumber());

            int affectedRows = ps.executeUpdate();

            if(affectedRows > 0){
                try (ResultSet rs = ps.getGeneratedKeys()) { // getGeneratedKeys() đã sẵn sàng
                    if(rs.next()){
                        customerID = rs.getInt(1);
                        customer.setCustomerID(customerID);
                    }
                }
            }

            return customerID;
        } catch (SQLException e) {
            System.err.println("Loi khi them Customer: " + e.getMessage());
            throw e;
        }
    }

    //Read by ID
    public Customer getCustomerByID(int customerID) throws SQLException {
        String sql = "Select CustomerID, FullName, Email, Phone, IdentifyNumber From Customer Where CustomerID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, customerID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractCustomerFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc Customer theo ID: " + e.getMessage());
            throw e;
        }
        return null;
    }

    //Read All
    public List<Customer> getAllCustomer() throws SQLException {
        List<Customer> customerList = new ArrayList<>();
        String sql = "Select CustomerID, FullName, Email, Phone, IdentifyNumber From Customer";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                customerList.add(extractCustomerFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc danh sach Customer: " + e.getMessage());
            throw e;
        }
        return customerList;
    }
    
    //Update
    public boolean updateCustomer(Customer customer) throws SQLException {
        if (customer == null) {
            throw new IllegalArgumentException("Customer khong duoc null");
        }
        
        String sql = "Update Customer Set FullName = ?, Email = ?, Phone = ?, IdentifyNumber = ? Where CustomerID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, customer.getFullName());
            ps.setString(2, customer.getEmail());
            ps.setString(3, customer.getPhone());
            ps.setString(4, customer.getIdentifyNumber());
            ps.setInt(5, customer.getCustomerID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi cap nhat Customer: " + e.getMessage());
            throw e;
        }
    }
    
    //Delete
    public boolean deleteCustomer(int customerID) throws SQLException {
        String sql = "Delete From Customer Where CustomerID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, customerID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi xoa Customer: " + e.getMessage());
            throw e;
        }
    }
    
    
    //Tim theo IdentifyID
    public Customer getCustomerByIdentifyNumber(String identifyNumber) throws SQLException {
        String sql = "SELECT CustomerID, FullName, Email, Phone, IdentifyNumber FROM CUSTOMER WHERE IdentifyNumber = ?";

        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, identifyNumber);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {

                    Customer existingCustomer = new Customer(
                        rs.getInt("CustomerID"),
                        rs.getString("FullName"),
                        rs.getString("Email"),
                        rs.getString("Phone"),
                        rs.getString("IdentifyNumber")
                    );
                    return existingCustomer;
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi kiem tra IdentifyNumber: " + e.getMessage());
            throw e; 
        }
        return null;
    }
    
    
}