package com.mycompany.ksan.model;

/**
 *
 * @author PHUC HIEP
 */
public class Room {
    private Integer roomID;
    private Integer hotelID;
    private Integer roomTypeID;
    private String roomNumber;
    private String status = "Available";

    public Room() {
    }

    public Room(Integer roomID, Integer hotelID, Integer roomTypeID, String roomNumber, String status) {
        this.roomID = roomID;
        this.hotelID = hotelID;
        this.roomTypeID = roomTypeID;
        this.roomNumber = roomNumber;
        this.status = status;
    }

    public Room(Integer hotelID, Integer roomTypeID, String roomNumber, String status) {
        this.hotelID = hotelID;
        this.roomTypeID = roomTypeID;
        this.roomNumber = roomNumber;
        this.status = status;
    }

    public Integer getRoomID() {
        return roomID;
    }

    public void setRoomID(Integer roomID) {
        if(roomID == null){
            throw new IllegalArgumentException("RoomID khong duoc de trong");
        }
        this.roomID = roomID;
    }

    public Integer getHotelID() {
        return hotelID;
    }

    public void setHotelID(Integer hotelID) {
        if(hotelID == null){
            throw new IllegalArgumentException("HotelID khong duoc de trong");
        }
        this.hotelID = hotelID;
        
    }

    public Integer getRoomTypeID() {
        return roomTypeID;
    }

    public void setRoomTypeID(Integer roomTypeID) {
        if(roomTypeID == null){
            throw new IllegalArgumentException("RoomTypeID khong duoc de trong");
        }
        this.roomTypeID = roomTypeID;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        if(roomNumber.isEmpty() || roomNumber.equals("")){
            throw new IllegalArgumentException("RoomNumber khong duoc de trong");
        }
        this.roomNumber = roomNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if(status.isEmpty() || status.equals("")){
            throw new IllegalArgumentException("Status khong duoc de trong");
        }
        this.status = status;
    }
    
    
}

