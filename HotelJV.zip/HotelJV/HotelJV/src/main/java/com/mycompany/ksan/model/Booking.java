/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author PHUC HIEP
 */
public class Booking {
    private Integer bookingID;
    private Integer customerID;
    private Integer timePeriodID;
    private LocalDate bookingDate;
    private LocalDateTime checkInDate;
    private LocalDateTime checkOutDate;
    private Integer numberOfGuest;
    private BigDecimal totalAmount;
    private String status;

    public Booking() {
        this.numberOfGuest = 1;
        this.bookingDate = LocalDate.now();
        this.totalAmount = BigDecimal.ZERO;
        this.status = "Pending";
    }

    public Booking(Integer bookingID, Integer customerID, Integer timePeriodID, LocalDate bookingDate, LocalDateTime checkInDate, LocalDateTime checkOutDate, Integer numberOfGuest, BigDecimal totalAmount, String status) {
        this.bookingID = bookingID;
        this.customerID = customerID;
        this.timePeriodID = timePeriodID;
        this.bookingDate = bookingDate;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.numberOfGuest = numberOfGuest;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    public Booking(Integer customerID, Integer timePeriodID, LocalDate bookingDate, LocalDateTime checkInDate, LocalDateTime checkOutDate, Integer numberOfGuest, BigDecimal totalAmount, String status) {
        this.customerID = customerID;
        this.timePeriodID = timePeriodID;
        this.bookingDate = bookingDate;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.numberOfGuest = numberOfGuest;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    

    public Integer getBookingID() {
        return bookingID;
    }

    public void setBookingID(Integer bookingID) {
        if(bookingID == null){
            throw new IllegalArgumentException("BookingID khong duoc de trong");
        }
        this.bookingID = bookingID;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        if(customerID == null){
            throw new IllegalArgumentException("CustomerID khong duoc de trong");
        }
        this.customerID = customerID;
    }

    public Integer getTimePeriodID() {
        return timePeriodID;
    }

    public void setTimePeriodID(Integer timePeriodID) {
        this.timePeriodID = timePeriodID;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        if(bookingDate == null){
            throw new IllegalArgumentException("BookingDate khong duoc de trong");
        }
        this.bookingDate = bookingDate;
    }

    public LocalDateTime getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(LocalDateTime checkInDate) {
        if(checkInDate == null){
            throw new IllegalArgumentException("CheckInDate khong duoc de trong");
        }
        this.checkInDate = checkInDate;
    }

    public LocalDateTime getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(LocalDateTime checkOutDate) {
        if(checkOutDate == null){
            throw new IllegalArgumentException("CheckOutDate khong duoc de trong");
        }
        this.checkOutDate = checkOutDate;
    }

    public Integer getNumberOfGuest() {
        return numberOfGuest;
    }

    public void setNumberOfGuest(Integer numberOfGuest) {
        if(numberOfGuest == null){
            throw new IllegalArgumentException("So luong khach khong duoc de trong");
        }
        this.numberOfGuest = numberOfGuest;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        if(totalAmount == null){
            throw new IllegalArgumentException("Tong tien khong duoc de trong");
        }
        
        BigDecimal max = new BigDecimal("9999999999.99");
        
        if(totalAmount.compareTo(BigDecimal.ZERO) < 0 || totalAmount.compareTo(max) > 0){
            throw new IllegalArgumentException("Tong tien vuot gioi han");
        }
        
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if(status.isEmpty() || status.equals("")){
            throw new IllegalArgumentException("Status khong duoc de trong");
        }
        this.status = status;
    }

    public boolean kiemTraNgay(){
        if(checkInDate == null || checkOutDate == null){
            throw new IllegalArgumentException("Ngay khong duoc de trong");
        }
        
        if(checkInDate.isAfter(checkOutDate)){
            return false;
        }
        return true;
    }
    
    
}
