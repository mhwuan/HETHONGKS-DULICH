package com.mycompany.ksan.controller;

import com.mycompany.ksan.model.Room;
import com.mycompany.ksan.dal.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.List;
import com.mycompany.ksan.dal.DBContext; 
import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;

public class Controller {
    
    private final BookingDAO bookingDAO;
    private final RoomDAO roomDAO;
    private final CustomerDAO customerDAO;
    private final HotelDAO hotelDAO;
    private final BookingRoomDAO bookingRoomDAO = new BookingRoomDAO();
    private final DBContext dbContext;
    
    private static final double HOURLY_MULTIPLIER = 1.5;
    private static final int MIN_HOURS = 3;
    
    public Controller(){
        this.bookingDAO = new BookingDAO();
        this.roomDAO = new RoomDAO();
        this.customerDAO = new CustomerDAO();
        this.hotelDAO = new HotelDAO();
        this.dbContext = new DBContext();
    }

    public List<Room> searchAvailableRooms(int hotelId, LocalDateTime checkIn, LocalDateTime checkOut) throws SQLException {
        return roomDAO.getAvailableRoomsByHotel(hotelId, checkIn, checkOut);
    }
    


    public BigDecimal calculateTotalAmount(BigDecimal basePrice, LocalDateTime checkIn, LocalDateTime checkOut, BigDecimal multiplier, long MIN_HOURS) {
        if (basePrice == null || checkIn == null || checkOut == null || multiplier == null) {
            throw new IllegalArgumentException("Tham so khong duoc null!");
        }

        if (checkOut.isBefore(checkIn) || checkOut.isEqual(checkIn)) {
            throw new IllegalArgumentException("Ngay check-out phai sau ngay check-in!");
        }

        // Áp dụng hệ số nhân vào giá cơ bản (cho cả thuê đêm và thuê giờ)
        BigDecimal adjustedBasePrice = basePrice.multiply(multiplier).setScale(2, BigDecimal.ROUND_HALF_UP);

        boolean isOvernight = checkOut.toLocalDate().isAfter(checkIn.toLocalDate());

        if (isOvernight) {
            // TRƯỜNG HỢP THUÊ QUA ĐÊM
            long nights = ChronoUnit.DAYS.between(checkIn.toLocalDate(), checkOut.toLocalDate());

            // Tổng tiền = Giá cơ bản đã điều chỉnh * Số đêm
            return adjustedBasePrice.multiply(BigDecimal.valueOf(nights)).setScale(2, BigDecimal.ROUND_HALF_UP);

        } else {
            // TRƯỜNG HỢP THUÊ TRONG NGÀY (THEO GIỜ)
            long totalMinutes = ChronoUnit.MINUTES.between(checkIn, checkOut);
            // Làm tròn lên thành giờ (ví dụ: 61 phút tính 2 giờ)
            long hours = (totalMinutes + 59) / 60;

            if (hours < MIN_HOURS) {
                hours = MIN_HOURS;
            }

            // Tính giá giờ từ giá cơ bản đã điều chỉnh
            // Giá giờ = Giá cơ bản đã điều chỉnh / 24 giờ
            BigDecimal hourlyRate = adjustedBasePrice.divide(BigDecimal.valueOf(24), 2, BigDecimal.ROUND_HALF_UP);

            // Tổng tiền = Giá giờ * Số giờ
            return hourlyRate.multiply(BigDecimal.valueOf(hours)).setScale(2, BigDecimal.ROUND_HALF_UP);
        }
    }

    public boolean removeRoomFromBooking(int bookingId, int customerId, int roomId) throws Exception {
        Connection conn = null;
        try {
            conn = dbContext.getConnection();
            conn.setAutoCommit(false); // BAT DAU TRANSACTION
            
            // 1. XOA BAN GHI PHONG CU THE (BOOKING_ROOM)
            boolean deleted = bookingRoomDAO.deleteBookingRoom(bookingId, customerId, roomId, conn);
            
            if (!deleted) {
                conn.rollback();
                throw new SQLException("Khong tim thay hoac khong the xoa phong da chon.");
            }
            
            // 2. CAP NHAT TRANG THAI PHONG (ROOM.STATUS -> Available)
            roomDAO.updateRoomStatus(roomId, "Available", conn);
            
            // 3. KIEM TRA SO PHONG CON LAI TRONG BOOKING NAY
            int remainingRooms = bookingRoomDAO.getRoomCountForBooking(bookingId, customerId, conn);
            
            if (remainingRooms == 0) {
                // 4. KHONG CON PHONG: CHUYEN TRANG THAI BOOKING CHINH SANG CANCELLED
                bookingDAO.updateBookingStatus(bookingId, customerId, "Cancelled", conn);
                conn.commit();
                return true; // Bao hieu master booking da bi huy
            }
            
            conn.commit(); // Chi xoa phong, master booking van ACTIVE
            return false;
            
        } catch (SQLException e) {
            if (conn != null) conn.rollback(); // ROLLBACK NEU CO LOI
            System.err.println("Loi Transaction khi xoa phong: " + e.getMessage());
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }
    
    
    

}