package com.mycompany.ksan.dal;

import com.mycompany.ksan.model.Room;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class RoomDAO {
    private final DBContext dbContext;
    
    public RoomDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private Room extractRoomFromResultSet(ResultSet rs) throws SQLException {
        Room room = new Room();
        room.setRoomID(rs.getInt("RoomID"));
        room.setHotelID(rs.getInt("Hotel_ID"));
        room.setRoomTypeID(rs.getInt("RoomTypeID"));
        
        try {
            room.setRoomNumber(rs.getString("RoomNumber"));
            room.setStatus(rs.getString("STATUS"));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        return room;
    }
    
    //Create/Insert
    public boolean insertRoom(Room room) throws SQLException {
        if (room == null) {
            throw new IllegalArgumentException("Room khong duoc null");
        }
        
        String sql = "Insert into ROOM (Hotel_ID, RoomTypeID, RoomNumber, STATUS) Values (?, ?, ?, ?)";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, room.getHotelID());
            ps.setInt(2, room.getRoomTypeID());
            ps.setString(3, room.getRoomNumber());
            ps.setString(4, room.getStatus());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi them Room: " + e.getMessage());
            throw e;
        }
    }
    
    //Read by ID
    public Room getRoomByID(Integer roomID) throws SQLException {
        String sql = "Select * From ROOM Where RoomID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, roomID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractRoomFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc theo ID: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    //Read All
    public List<Room> getAllRooms() throws SQLException {
        List<Room> roomList = new ArrayList<>();
        String sql = "Select * From ROOM";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                roomList.add(extractRoomFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc danh sach Room: " + e.getMessage());
            throw e;
        }
        return roomList;
    }
    
    //Get Available Rooms by Hotel
    public List<Room> getAvailableRoomsByHotel(int hotelId, LocalDateTime checkIn, LocalDateTime checkOut) throws SQLException {
        List<Room> list = new ArrayList<>();

        
        String sql = "SELECT R.* FROM ROOM R WHERE R.Hotel_ID = ? " +
                     "AND NOT EXISTS (" +
                        "SELECT 1 FROM BOOKING_ROOM BR " +
                        "JOIN BOOKING B ON BR.BookingID = B.BookingID " +
                        "WHERE BR.RoomID = R.RoomID " +
                        "AND B.STATUS NOT IN ('Cancelled', 'CheckedOut') " + // Bỏ qua đơn đã hủy hoặc đã trả
                        "AND B.Check_Out_Date > ? " +  // Tham số 2: CheckIn của khách mới
                        "AND B.Check_In_Date < ?" +   // Tham số 3: CheckOut của khách mới
                     ")";

        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // 1. Set Hotel ID
            ps.setInt(1, hotelId);

            // 2. Set Ngày giờ (JDBC hỗ trợ setObject cho LocalDateTime)
            ps.setObject(2, checkIn);
            ps.setObject(3, checkOut);

            // 3. Thực thi và ánh xạ kết quả
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                   
                    Room room = extractRoomFromResultSet(rs);
                    list.add(room);
                }
            }

        } catch (SQLException e) {
            System.err.println("Lỗi khi tìm phòng trống (getAvailableRoomsByHotel): " + e.getMessage());
            throw e; 
        }
        
        return list;
    }
    
    //Update
    public boolean updateRoom(Room room) throws SQLException {
        if (room == null) {
            throw new IllegalArgumentException("Room khong duoc null");
        }
        
        String sql = "Update ROOM set Hotel_ID = ?, RoomTypeID = ?, RoomNumber = ?, STATUS = ? Where RoomID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, room.getHotelID());
            ps.setInt(2, room.getRoomTypeID());
            ps.setString(3, room.getRoomNumber());
            ps.setString(4, room.getStatus());
            ps.setInt(5, room.getRoomID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
            
        } catch (SQLException e) {
            System.err.println("Loi khi cap nhat Room: " + e.getMessage());
            throw e;
        }
    }
    
    //Delete
    public boolean deleteRoom(int roomID) throws SQLException {
        String sql = "Delete From ROOM Where RoomID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, roomID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
            
        } catch (SQLException e) {
            System.err.println("Loi khi xoa Room: " + e.getMessage());
            throw e;
        }
    }
    
    public BigDecimal getBasePrice (Integer roomTypeID){
        BigDecimal basePrice = BigDecimal.ZERO;
        String sql = "Select BasePrice From ROOM_TYPE Where RoomTypeID = ?";
        
        try (Connection conn = dbContext.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setInt(1, roomTypeID);
            try (ResultSet rs = ps.executeQuery()){
                if(rs.next()){
                    basePrice = rs.getBigDecimal("BasePrice");
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi tim BasePrice: " + e.getMessage());
            throw new RuntimeException("Database error finding BasePrice", e);
        }
        return basePrice;
    }
    
    public boolean updateRoomStatus(int roomId, String status, Connection conn) throws SQLException {
        String sql = "UPDATE ROOM SET STATUS = ? WHERE RoomID = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status); 
            ps.setInt(2, roomId);

            return ps.executeUpdate() > 0;
        } 
        // KHÔNG cần khối catch ở đây vì Exception sẽ được ném lên Service để Rollback
    }

}    