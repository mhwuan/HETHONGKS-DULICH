/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author PHUC HIEP
 */
public class Review {
    private Integer reviewID;
    private Integer bookingID;
    private Integer customerID;
    private BigDecimal rating;
    private String comment;
    private LocalDate reviewDate;

    public Review() {
        this.reviewDate = LocalDate.now();
    }

    public Review(Integer reviewID, Integer bookingID, Integer customerID, BigDecimal rating, String comment, LocalDate reviewDate) {
        this.reviewID = reviewID;
        this.bookingID = bookingID;
        this.customerID = customerID;
        this.rating = rating;
        this.comment = comment;
        this.reviewDate = reviewDate;
    }

    public Review(Integer bookingID, Integer customerID, BigDecimal rating, String comment, LocalDate reviewDate) {
        this.bookingID = bookingID;
        this.customerID = customerID;
        this.rating = rating;
        this.comment = comment;
        this.reviewDate = reviewDate;
    }

    public Integer getReviewID() {
        return reviewID;
    }

    public void setReviewID(Integer reviewID) {
        if(reviewID == null){
            throw new IllegalArgumentException("ReviewID khong duoc de trong");
        }
        this.reviewID = reviewID;
    }

    public Integer getBookingID() {
        return bookingID;
    }

    public void setBookingID(Integer bookingID) {
        if(bookingID == null){
            throw new IllegalArgumentException("BookingID khong duoc de trong");
        }
        this.bookingID = bookingID;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        if(customerID == null){
            throw new IllegalArgumentException("CustomerID khong duoc de trong");
        }
        this.customerID = customerID;
    }

    public BigDecimal getRating() {
        return rating;
    }

    public void setRating(BigDecimal rating) {
        if(rating == null){
            throw new IllegalArgumentException("Rating khong duoc de trong");
        }
        
        BigDecimal max = new BigDecimal("5");
        
        if(rating.compareTo(BigDecimal.ONE) < 0 || rating.compareTo(max) > 0){
            throw new IllegalArgumentException("Rating lon hon 1 va nho hon 5");
        }
        
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDate getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(LocalDate reviewDate) {
        if(reviewDate == null){
            throw new IllegalArgumentException("ReviewDate khong duoc de trong");
        }
        this.reviewDate = reviewDate;
    }
    
    
}
