package com.mycompany.ksan.dal;

import com.mycompany.ksan.model.Hotel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class HotelDAO {
    private final DBContext dbContext;
    
    public HotelDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private Hotel extractHotelFromResultSet(ResultSet rs) throws SQLException {
        Hotel hotel = new Hotel();
        hotel.setHotel_ID(rs.getInt("Hotel_ID"));
        
        try {
            hotel.setHotelName(rs.getString("HotelName"));
            hotel.setStarRating(rs.getBigDecimal("StarRating"));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        hotel.setAddress(rs.getString("Address"));
        hotel.setPhone(rs.getString("Phone"));
        hotel.setEmail(rs.getString("Email"));
        hotel.setDescription(rs.getString("Description"));
        return hotel;
    }
    
    //Create
    public boolean insertHotel(Hotel hotel) throws SQLException {
        if (hotel == null) {
            throw new IllegalArgumentException("Hotel không được null");
        }
        
        String sql = "INSERT INTO Hotel (HotelName, Address, StarRating, Phone, Email, Description) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, hotel.getHotelName());
            ps.setString(2, hotel.getAddress());
            ps.setBigDecimal(3, hotel.getStarRating());
            ps.setString(4, hotel.getPhone());
            ps.setString(5, hotel.getEmail());
            ps.setString(6, hotel.getDescription());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Lỗi khi thêm Hotel: " + e.getMessage());
            throw e; // Re-throw để tầng trên xử lý
        }
    }
    
    //Read by ID
    public Hotel getHotelByID(int hotel_ID) throws SQLException {
        String sql = "SELECT * FROM Hotel WHERE Hotel_ID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, hotel_ID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractHotelFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi đọc Hotel theo ID: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    //Read All
    public List<Hotel> getAllHotel() throws SQLException {
        List<Hotel> hotelList = new ArrayList<>();
        String sql = "SELECT * FROM Hotel";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                hotelList.add(extractHotelFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi đọc danh sách Hotel: " + e.getMessage());
            throw e;
        }
        return hotelList;
    }
    
    //Update
    public boolean updateHotel(Hotel hotel) throws SQLException {
        if (hotel == null) {
            throw new IllegalArgumentException("Hotel không được null");
        }
        
        String sql = "UPDATE Hotel SET HotelName = ?, Address = ?, StarRating = ?, " +
                     "Phone = ?, Email = ?, Description = ? WHERE Hotel_ID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, hotel.getHotelName());
            ps.setString(2, hotel.getAddress());
            ps.setBigDecimal(3, hotel.getStarRating());
            ps.setString(4, hotel.getPhone());
            ps.setString(5, hotel.getEmail());
            ps.setString(6, hotel.getDescription());
            ps.setInt(7, hotel.getHotel_ID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Lỗi khi cập nhật Hotel: " + e.getMessage());
            throw e;
        }
    }
    
    //Delete
    public boolean deleteHotel(int hotel_ID) throws SQLException {
        String sql = "DELETE FROM Hotel WHERE Hotel_ID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, hotel_ID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Lỗi khi xóa Hotel: " + e.getMessage());
            throw e;
        }
    }
    public List<String> getAllHotelNames() throws SQLException {
        List<String> hotelNames = new ArrayList<>();
        String sql = "SELECT HotelName FROM Hotel";

   
        try (Connection conn = dbContext.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                hotelNames.add(rs.getString("HotelName")); 
            }
        } catch (SQLException e) {
            System.err.println("Loi khi tai danh sach khach san: " + e.getMessage());
            throw e;
        }
        return hotelNames;
    }
    
    
    //HotelID by HotelName
    public int getIDByName (String name) throws SQLException {
        int hotelID = 0;
        String sql = "Select Hotel_ID From Hotel Where HotelName = ?";

        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setString(1, name);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Lay Hotel_ID va gan vao bien hotelID
                    hotelID = rs.getInt("Hotel_ID"); 
                }
            }

        } catch (SQLException e) {
            System.err.println("Loi khi tim Hotel ID: " + e.getMessage());
            throw e; 
        }
        return hotelID; 
    }
}