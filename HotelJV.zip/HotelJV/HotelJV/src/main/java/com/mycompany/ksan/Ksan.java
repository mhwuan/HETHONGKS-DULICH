package com.mycompany.ksan;

import com.mycompany.ksan.ui.CancelRoomUI;
import com.mycompany.ksan.ui.CustomerUI;
import com.mycompany.ksan.ui.HomeUI;
import com.mycompany.ksan.ui.InformationHotelsUI;
import com.mycompany.ksan.ui.RoomSelectionUI;
import com.mycompany.ksan.ui.SeeReviewUI;



/**
 *
 * @author PHUC HIEP
 */
public class Ksan {

    public static void main(String[] args) {
        HomeUI test = new HomeUI();
        test.setVisible(true);
        
    }
    
}