package com.mycompany.ksan.dal;

import com.mycompany.ksan.model.Review;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class ReviewDAO {
    private final DBContext dbContext;
    
    public ReviewDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private Review extractReviewFromResultSet(ResultSet rs) throws SQLException {
        Review review = new Review();
        review.setReviewID(rs.getInt("ReviewID"));
        review.setBookingID(rs.getInt("BookingID"));
        review.setCustomerID(rs.getInt("CustomerID"));
        
        try {
            review.setRating(rs.getBigDecimal("Rating"));
            review.setReviewDate(rs.getObject("ReviewDate", LocalDate.class));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        review.setComment(rs.getString("Comment"));
        return review;
    }
    
    //Insert/Create
    public boolean insertReview(Review review) throws SQLException {
        if (review == null) {
            throw new IllegalArgumentException("Review khong duoc null");
        }
        
        String sql = "Insert into REVIEW (BookingID, CustomerID, Rating, Comment, ReviewDate) Values (?, ?, ?, ?, ?)";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, review.getBookingID());
            ps.setInt(2, review.getCustomerID());
            ps.setBigDecimal(3, review.getRating());
            ps.setString(4, review.getComment());
            ps.setObject(5, review.getReviewDate());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi them Review: " + e.getMessage());
            throw e;
        }
    }
    
    //Read by ID
    public Review getReviewByID(int reviewID) throws SQLException {
        String sql = "Select * From REVIEW Where ReviewID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, reviewID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractReviewFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc Review theo ID: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    //Read All
    public List<Review> getAllReviews() throws SQLException {
        List<Review> reviewList = new ArrayList<>();
        String sql = "Select * From REVIEW";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                reviewList.add(extractReviewFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc danh sach Review: " + e.getMessage());
            throw e;
        }
        return reviewList;
    }
    
    //Update
    public boolean updateReview(Review review) throws SQLException {
        if (review == null) {
            throw new IllegalArgumentException("Review khong duoc null");
        }
        
        String sql = "Update REVIEW Set Rating = ?, Comment = ?, ReviewDate = ? Where ReviewID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setBigDecimal(1, review.getRating());
            ps.setString(2, review.getComment());
            ps.setObject(3, review.getReviewDate());
            ps.setInt(4, review.getReviewID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi cap nhat Review: " + e.getMessage());
            throw e;
        }
    }
    
    //Delete
    public boolean deleteReview(int reviewID) throws SQLException {
        String sql = "Delete From REVIEW Where ReviewID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, reviewID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi xoa Review: " + e.getMessage());
            throw e;
        }
    }
    
    
    //Review by hotelID
    public List<Review> getReviewsByHotelId(int hotelId) throws SQLException {
        List<Review> reviewList = new ArrayList<>();
        
        String sql = "SELECT DISTINCT Rev.* FROM REVIEW Rev "
                   + "JOIN BOOKING_ROOM BR ON Rev.BookingID = BR.BookingID AND Rev.CustomerID = BR.CustomerID "
                   + "JOIN ROOM R ON BR.RoomID = R.RoomID "
                   + "WHERE R.Hotel_ID = ? "
                   + "ORDER BY Rev.ReviewDate DESC";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, hotelId);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    reviewList.add(extractReviewFromResultSet(rs)); 
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc danh sach Review theo Hotel ID: " + e.getMessage());
            throw e;
        }
        return reviewList;
    }
}