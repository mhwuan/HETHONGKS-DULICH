package com.mycompany.ksan.dal;

import com.mycompany.ksan.dto.CustomerBookingSummaryDTO;
import com.mycompany.ksan.model.Booking;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class BookingDAO {
    private final DBContext dbContext;
    
    public BookingDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private Booking extractBookingFromResultSet(ResultSet rs) throws SQLException {
        Booking booking = new Booking();
        booking.setBookingID(rs.getInt("BookingID"));
        booking.setCustomerID(rs.getInt("CustomerID"));
        
        Integer timePeriodId = rs.getObject("TimePeriodID", Integer.class);
        booking.setTimePeriodID(timePeriodId);
        
        try {
            booking.setBookingDate(rs.getObject("BookingDate", LocalDate.class));
            booking.setCheckInDate(rs.getObject("Check_In_Date", LocalDateTime.class));
            booking.setCheckOutDate(rs.getObject("Check_Out_Date", LocalDateTime.class));
            booking.setNumberOfGuest(rs.getInt("NumberOfGuests"));
            booking.setTotalAmount(rs.getBigDecimal("TotalAmount"));
            booking.setStatus(rs.getString("STATUS"));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        return booking;
    }
    
    //Insert/Create
    public int insertBooking(Booking booking) throws SQLException {
        if (booking == null) {
            throw new IllegalArgumentException("Booking khong duoc null");
        }

        if (!booking.kiemTraNgay()) {
            throw new IllegalArgumentException("Loi logic ngay CheckIn lon hon ngay CheckOut");
        }

        String sql = "INSERT INTO BOOKING (CustomerID, TimePeriodID, BookingDate, Check_In_Date, Check_Out_Date, NumberOfGuests, TotalAmount, STATUS) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        int newBookingID = -1;

        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, booking.getCustomerID());

            if (booking.getTimePeriodID() == null) {
                ps.setNull(2, java.sql.Types.INTEGER);
            } else {
                ps.setInt(2, booking.getTimePeriodID());
            }

            ps.setObject(3, booking.getBookingDate());
            ps.setObject(4, booking.getCheckInDate());
            ps.setObject(5, booking.getCheckOutDate());
            ps.setInt(6, booking.getNumberOfGuest());
            ps.setBigDecimal(7, booking.getTotalAmount());
            ps.setString(8, booking.getStatus());

            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                try (java.sql.ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        newBookingID = generatedKeys.getInt(1); 
                    }
                }
            }

            return newBookingID;

        } catch (SQLException e) {
            System.err.println("Loi khi them Booking: " + e.getMessage());
            throw e;
        }
    }
    
    //Read by ID
    public Booking getBookingByID(int bookingID) throws SQLException {
        String sql = "Select * From BOOKING Where BookingID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, bookingID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractBookingFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc Booking theo ID: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    //Read All
    public List<Booking> getAllBookings() throws SQLException {
        List<Booking> bookingList = new ArrayList<>();
        String sql = "Select * From BOOKING";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                bookingList.add(extractBookingFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc danh sach Booking: " + e.getMessage());
            throw e;
        }
        return bookingList;
    }
    
    //Update
    public boolean updateBooking(Booking booking) throws SQLException {
        if (booking == null) {
            throw new IllegalArgumentException("Booking khong duoc null");
        }
        
        if (!booking.kiemTraNgay()) {
            throw new IllegalArgumentException("Loi logic ngay CheckOut phai sau ngay CheckIn");
        }
        
        String sql = "Update BOOKING Set CustomerID = ?, TimePeriodID = ?, BookingDate = ?, Check_In_Date = ?, Check_Out_Date = ?, NumberOfGuests = ?, TotalAmount = ?, STATUS = ? Where BookingID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, booking.getCustomerID());
            
            if (booking.getTimePeriodID() == null) {
                ps.setNull(2, java.sql.Types.INTEGER);
            } else {
                ps.setInt(2, booking.getTimePeriodID());
            }
            
            ps.setObject(3, booking.getBookingDate());
            ps.setObject(4, booking.getCheckInDate());
            ps.setObject(5, booking.getCheckOutDate());
            ps.setInt(6, booking.getNumberOfGuest());
            ps.setBigDecimal(7, booking.getTotalAmount());
            ps.setString(8, booking.getStatus());
            ps.setInt(9, booking.getBookingID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi cap nhat Booking: " + e.getMessage());
            throw e;
        }
    }

    //Delete
    public boolean deleteBooking(int bookingID) throws SQLException {
        String sql = "Delete From BOOKING Where BookingID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, bookingID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
            
        } catch (SQLException e) {
            System.err.println("Loi khi xoa Booking: " + e.getMessage());
            throw e;
        }
    }
    
    public boolean updateBookingStatusAndAmount(int bookingID, String newStatus, BigDecimal totalAmount) throws SQLException {

        // Câu lệnh SQL: Cập nhật cả Status và TotalAmount
        String sql = "UPDATE BOOKING SET Status = ?, TotalAmount = ? WHERE BookingID = ?";

        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newStatus);
            ps.setBigDecimal(2, totalAmount); // Gán tham số cho TotalAmount
            ps.setInt(3, bookingID);

            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            System.err.println("Loi khi cap nhat trang thai va tong tien Booking: " + e.getMessage());
            throw e;
        }
    }
    
    
    public List<CustomerBookingSummaryDTO> getActiveBookingSummary(String identifyNumber) throws SQLException {
        List<CustomerBookingSummaryDTO> summaryList = new ArrayList<>();

        String sql = "SELECT B.BookingID, BR.RoomID, H.HotelName, R.RoomNumber, B.Check_In_Date, B.Check_Out_Date "
                   + "FROM CUSTOMER C "
                   + "JOIN BOOKING B ON C.CustomerID = B.CustomerID "
                   + "JOIN BOOKING_ROOM BR ON B.BookingID = BR.BookingID AND B.CustomerID = BR.CustomerID "
                   + "JOIN ROOM R ON BR.RoomID = R.RoomID "
                   + "JOIN HOTEL H ON R.Hotel_ID = H.Hotel_ID "
                   + "WHERE C.IdentifyNumber = ? AND B.STATUS NOT IN ('Cancelled', 'CheckedOut') "
                   + "ORDER BY B.Check_In_Date ASC";

        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, identifyNumber);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    summaryList.add(new CustomerBookingSummaryDTO(
                        rs.getInt("BookingID"),
                        rs.getInt("RoomID"), 
                        rs.getString("HotelName"),
                        rs.getString("RoomNumber"),
                        rs.getObject("Check_In_Date", LocalDateTime.class),
                        rs.getObject("Check_Out_Date", LocalDateTime.class)
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi tim lich su dat phong theo Identify: " + e.getMessage());
            throw e;
        }
        return summaryList;
    }
    
    
    
    public boolean updateBookingStatus(int bookingId, int customerId, String status, Connection conn) throws SQLException {
        String sql = "UPDATE BOOKING SET STATUS = ? WHERE BookingID = ? AND CustomerID = ?";

        // Sử dụng Connection đã truyền vào
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status); 
            ps.setInt(2, bookingId);
            ps.setInt(3, customerId);

            return ps.executeUpdate() > 0;
        }
        // KHÔNG cần khối catch ở đây vì Exception sẽ được ném lên Service để Rollback
    }
    
}