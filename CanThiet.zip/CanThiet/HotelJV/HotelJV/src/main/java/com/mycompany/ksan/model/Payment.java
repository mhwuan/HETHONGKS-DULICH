/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author PHUC HIEP
 */
public class Payment {
    private Integer paymentID;
    private Integer bookingID;
    private Integer customerID;
    private LocalDate paymentDate;
    private String paymentMethod;
    private BigDecimal amount;
    private String paymentStatus;
    private String transactionID;

    public Payment() {
        this.paymentDate = LocalDate.now();
        this.paymentStatus = "Pending";
    }

    public Payment(Integer paymentID, Integer bookingID, Integer customerID, LocalDate paymentDate, String paymentMethod, BigDecimal amount, String paymentStatus, String transactionID) {
        this.paymentID = paymentID;
        this.bookingID = bookingID;
        this.customerID = customerID;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.amount = amount;
        this.paymentStatus = paymentStatus;
        this.transactionID = transactionID;
    }

    public Payment(Integer bookingID, Integer customerID, LocalDate paymentDate, String paymentMethod, BigDecimal amount, String paymentStatus, String transactionID) {
        this.bookingID = bookingID;
        this.customerID = customerID;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.amount = amount;
        this.paymentStatus = paymentStatus;
        this.transactionID = transactionID;
    }

    public Integer getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(Integer paymentID) {
        if(paymentID == null){
            throw new IllegalArgumentException("PaymentID khong duoc de trong");
        }
        this.paymentID = paymentID;
    }

    public Integer getBookingID() {
        return bookingID;
    }

    public void setBookingID(Integer bookingID) {
        if(bookingID == null){
            throw new IllegalArgumentException("BookingID khong duoc de trong");
        }
        this.bookingID = bookingID;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        if(customerID == null){
            throw new IllegalArgumentException("CustomerID khong duoc de trong");
        }
        this.customerID = customerID;
    }


    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        if(paymentDate == null){
            throw new IllegalArgumentException("PaymentDate khong duoc de trong");
        }
        this.paymentDate = paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        if(paymentMethod == null || paymentMethod.isEmpty() || paymentMethod.equals("")){
            throw new IllegalArgumentException("PaymentMethod khong duoc de trong");
        }
        this.paymentMethod = paymentMethod;
    }
    
    
    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        if(amount == null){
            throw new IllegalArgumentException("Tong tien khong duoc de trong");
        }
        
        BigDecimal max = new BigDecimal("9999999999.99");
        
        if(amount.compareTo(BigDecimal.ZERO) < 0 || amount.compareTo(max) > 0){
            throw new IllegalArgumentException("Tong tien vuot gioi han");
        }
        
        this.amount = amount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        if(paymentStatus == null || paymentStatus.isEmpty() || paymentStatus.equals("")){
            throw new IllegalArgumentException("PaymentStatus khong duoc de trong");
        }
        this.paymentStatus = paymentStatus;
    }


    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }
    
    
}
