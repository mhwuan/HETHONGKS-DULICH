/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.model;

import java.math.BigDecimal;

/**
 *
 * @author PHUC HIEP
 */
public class Hotel {
    private Integer hotel_ID;
    private String hotelName;
    private String address;
    private BigDecimal starRating;
    private String phone;
    private String email;
    private String description;

    public Hotel() {
    }

    public Hotel(Integer hotel_ID, String hotelName, String address, BigDecimal starRating, String phone, String email, String description) {
        this.hotel_ID = hotel_ID;
        this.hotelName = hotelName;
        this.address = address;
        this.starRating = starRating;
        this.phone = phone;
        this.email = email;
        this.description = description;
    }

    public Hotel(String hotelName, String address, BigDecimal starRating, String phone, String email, String description) {
        this.hotelName = hotelName;
        this.address = address;
        this.starRating = starRating;
        this.phone = phone;
        this.email = email;
        this.description = description;
    }
    
    

    public Integer getHotel_ID() {
        return hotel_ID;
    }

    public void setHotel_ID(Integer hotel_ID) {
        this.hotel_ID = hotel_ID;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        if(hotelName.isEmpty() || hotelName.equals("")){
            throw new IllegalArgumentException("Ten khach san khong duoc de trong");
        }
        this.hotelName = hotelName;
        
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public BigDecimal getStarRating() {
        return starRating;
    }

    public void setStarRating(BigDecimal starRating) {
        BigDecimal min = new BigDecimal("1.0");
        BigDecimal max = new BigDecimal("5.0");
        if (starRating.compareTo(min) < 0 || starRating.compareTo(max) > 0) {
            throw new IllegalArgumentException("Sao danh gia phai nam trong khoang tu 1.0 den 5.0");
        }
        this.starRating = starRating;
    }
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
}
