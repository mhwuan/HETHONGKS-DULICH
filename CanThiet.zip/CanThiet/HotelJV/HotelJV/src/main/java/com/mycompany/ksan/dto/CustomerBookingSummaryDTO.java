/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.dto;

import java.time.LocalDateTime;

/**
 *
 * @author PHUC HIEP
 */
public class CustomerBookingSummaryDTO {
    private  int bookingID; 
    private  int roomID; 
    private  String hotelName;
    private  String roomNumber;
    private  LocalDateTime checkInDate;
    private  LocalDateTime checkOutDate;

    public CustomerBookingSummaryDTO() {
    }
    
    
    public int getBookingID() {
        return bookingID;
    }

    public int getRoomID() {
        return roomID;
    }

    public String getHotelName() {
        return hotelName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public LocalDateTime getCheckInDate() {
        return checkInDate;
    }

    public LocalDateTime getCheckOutDate() {
        return checkOutDate;
    }

    public CustomerBookingSummaryDTO(int bookingID, int roomID, String hotelName, String roomNumber, LocalDateTime checkInDate, LocalDateTime checkOutDate) {
        this.bookingID = bookingID;
        this.roomID = roomID;
        this.hotelName = hotelName;
        this.roomNumber = roomNumber;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    
    
    
}
