package com.mycompany.ksan.dal;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBContext {

    private final String SERVER_NAME = "localhost";
    private final String DB_NAME = "HotelReservationDB";
    private final String PORT_NUMBER = "1433";
    private final String USER = "sa"; // Thay bằng tên người dùng SQL Server của bạn
    private final String PASSWORD = "sa"; // Thay bằng mật khẩu của bạn

    public Connection getConnection() {
        Connection conn = null;
        
        String url = "jdbc:sqlserver://" + SERVER_NAME + ":" + PORT_NUMBER + 
                     ";databaseName=" + DB_NAME + 
                     ";encrypt=true;trustServerCertificate=true"; 

        try {
            
            conn = DriverManager.getConnection(url, USER, PASSWORD);
            
            // In ra thông báo kiểm tra (chỉ dùng khi test)
            System.out.println("DB thanh cong");

        } catch (SQLException e) {
            System.err.println("DB loi: " + e.getMessage());
            e.printStackTrace();
        } 
        
        return conn;
    }
    
  
}
