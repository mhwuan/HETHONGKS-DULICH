package com.mycompany.ksan.dal;

import com.mycompany.ksan.model.BookingRoom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class BookingRoomDAO {
    private final DBContext dbContext;
    
    public BookingRoomDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private BookingRoom extractBookingRoomFromResultSet(ResultSet rs) throws SQLException {
        BookingRoom br = new BookingRoom();
        br.setBookingID(rs.getInt("BookingID"));
        br.setCustomerID(rs.getInt("CustomerID"));
        br.setRoomID(rs.getInt("RoomID"));
        
        try {
            br.setRoomPrice(rs.getBigDecimal("RoomPrice"));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        return br;
    }
    
    //Insert/Create
    public boolean insertBookingRoom(BookingRoom br) throws SQLException {
        if (br == null) {
            throw new IllegalArgumentException("BookingRoom khong duoc null");
        }
        
        String sql = "Insert into BOOKING_ROOM (BookingID, CustomerID, RoomID, RoomPrice) Values (?, ?, ?, ?)";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, br.getBookingID());
            ps.setInt(2, br.getCustomerID());
            ps.setInt(3, br.getRoomID());
            ps.setBigDecimal(4, br.getRoomPrice());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi them BookingRoom: " + e.getMessage());
            throw e;
        }
    }
    
    //Read by Primary Key
    public BookingRoom getBookingRoomByPK(int bookingID, int customerID, int roomID) throws SQLException {
        String sql = "Select * From BOOKING_ROOM Where BookingID = ? And CustomerID = ? And RoomID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, bookingID);
            ps.setInt(2, customerID);
            ps.setInt(3, roomID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractBookingRoomFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc BookingRoom theo PK: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    //Read by BookingID
    public List<BookingRoom> getRoomsByBookingID(int bookingID) throws SQLException {
        List<BookingRoom> roomList = new ArrayList<>();
        String sql = "Select * From BOOKING_ROOM Where BookingID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, bookingID);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    roomList.add(extractBookingRoomFromResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc theo BookingID: " + e.getMessage());
            throw e;
        }
        return roomList;
    }
    
    //Update
    public boolean updateBookingRoomPrice(BookingRoom br) throws SQLException {
        if (br == null) {
            throw new IllegalArgumentException("BookingRoom khong duoc null");
        }
        
        String sql = "Update BOOKING_ROOM Set RoomPrice = ? Where BookingID = ? And CustomerID = ? And RoomID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setBigDecimal(1, br.getRoomPrice());
            ps.setInt(2, br.getBookingID());
            ps.setInt(3, br.getCustomerID());
            ps.setInt(4, br.getRoomID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi cap nhat BookingRoom: " + e.getMessage());
            throw e;
        }
    }
    
    //Delete
    public boolean deleteBookingRoom(int bookingID, int customerID, int roomID, Connection conn) throws SQLException {        String sql = "Delete From BOOKING_ROOM Where BookingID = ? And CustomerID = ? And RoomID = ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, bookingID);
            ps.setInt(2, customerID);
            ps.setInt(3, roomID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi xoa BookingRoom: " + e.getMessage());
            throw e;
        }
    }
    
    
    public int getRoomCountForBooking(int bookingId, int customerId, Connection conn) throws SQLException {
        int count = 0;
        // Đếm các bản ghi có cùng BookingID và CustomerID
        String sql = "SELECT COUNT(RoomID) FROM BOOKING_ROOM WHERE BookingID = ? AND CustomerID = ?";

        // Sử dụng Connection đã truyền vào
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            ps.setInt(2, customerId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt(1); // Lấy giá trị của hàm COUNT
                }
            }
        } 
        return count;
    }
}