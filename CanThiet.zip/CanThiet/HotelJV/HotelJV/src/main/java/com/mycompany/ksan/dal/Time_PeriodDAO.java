package com.mycompany.ksan.dal;

import com.mycompany.ksan.dto.PeriodMultiplierDTO;
import com.mycompany.ksan.model.Time_period;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class Time_PeriodDAO {
    private final DBContext dbContext;
    
    public Time_PeriodDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private Time_period extractTimePeriodFromResultSet(ResultSet rs) throws SQLException {
        Time_period period = new Time_period();
        period.setTimePeriodID(rs.getInt("TimePeriodID"));
        period.setHotelID(rs.getInt("Hotel_ID"));
        
        try {
            period.setPeriodName(rs.getString("PeriodName"));
            period.setStartDate(rs.getObject("StartDate", LocalDate.class));
            period.setEndDate(rs.getObject("EndDate", LocalDate.class));
            period.setPriceMult(rs.getBigDecimal("PriceMultiplier"));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        return period;
    }
    
    //Insert/Create
    public boolean insertTimePeriod(Time_period period) throws SQLException {
        if (period == null) {
            throw new IllegalArgumentException("Time_period khong duoc null");
        }
        
        if (!period.kiemTraHopLe()) {
            throw new IllegalArgumentException("Ngay ket thuc phai lon hon ngay bat dau");
        }
        
        String sql = "Insert into TIME_PERIOD (Hotel_ID, PeriodName, StartDate, EndDate, PriceMultiplier) Values (?, ?, ?, ?, ?)";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, period.getHotelID());
            ps.setString(2, period.getPeriodName());
            ps.setObject(3, period.getStartDate());
            ps.setObject(4, period.getEndDate());
            ps.setBigDecimal(5, period.getPriceMult());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi them TimePeriod: " + e.getMessage());
            throw e;
        }
    }
    
    //Read by ID
    public Time_period getTimePeriodByID(int timePeriodID) throws SQLException {
        String sql = "Select * From TIME_PERIOD Where TimePeriodID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, timePeriodID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractTimePeriodFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc TimePeriod theo ID: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    //Read All
    public List<Time_period> getAllTimePeriods() throws SQLException {
        List<Time_period> periodList = new ArrayList<>();
        String sql = "Select * From TIME_PERIOD";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                periodList.add(extractTimePeriodFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Loi khi doc danh sach TimePeriod: " + e.getMessage());
            throw e;
        }
        return periodList;
    }
    
    //Update
    public boolean updateTimePeriod(Time_period period) throws SQLException {
        if (period == null) {
            throw new IllegalArgumentException("Time_period khong duoc null");
        }
        
        if (!period.kiemTraHopLe()) {
            throw new IllegalArgumentException("Ngay ket thuc phai lon hon ngay bat dau");
        }
        
        String sql = "Update TIME_PERIOD Set Hotel_ID = ?, PeriodName = ?, StartDate = ?, EndDate = ?, PriceMultiplier = ? Where TimePeriodID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, period.getHotelID());
            ps.setString(2, period.getPeriodName());
            ps.setObject(3, period.getStartDate());
            ps.setObject(4, period.getEndDate());
            ps.setBigDecimal(5, period.getPriceMult());
            ps.setInt(6, period.getTimePeriodID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi cap nhat TimePeriod: " + e.getMessage());
            throw e;
        }
    }
    
    //Delete
    public boolean deleteTimePeriod(int timePeriodID) throws SQLException {
        String sql = "Delete From TIME_PERIOD Where TimePeriodID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, timePeriodID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
            
        } catch (SQLException e) {
            System.err.println("Loi khi xoa TimePeriod: " + e.getMessage());
            throw e;
        }
    }
    
    
    //GetPeriod
    public Time_period getTimePeriodByDate(int hotelId, LocalDate checkInDate) throws SQLException {
        
        // SQL: Tìm bản ghi có Hotel_ID khớp và ngày checkIn nằm trong StartDate và EndDate
        String sql = "SELECT TOP 1 * FROM TIME_PERIOD " + // Dùng TOP 1 vì chỉ cần 1 giai đoạn
                     "WHERE Hotel_ID = ? " +
                       "AND ? BETWEEN StartDate AND EndDate"; 
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, hotelId);
            // Sử dụng setObject cho LocalDate
            ps.setObject(2, checkInDate); 
           

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Sử dụng hàm helper đã có để ánh xạ kết quả sang Entity
                    return extractTimePeriodFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi tim TimePeriod theo ngay: " + e.getMessage());
            throw e;
        }
        return null;
    }
}