/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author PHUC HIEP
 */
public class Time_period {
    private Integer timePeriodID;
    private Integer hotelID;
    private String periodName;
    private LocalDate startDate;
    private LocalDate endDate;
    private BigDecimal priceMult;

    public Time_period() {
        this.priceMult = BigDecimal.ONE;
    }

    public Time_period(Integer timePeriodID, Integer hotelID, String periodName, LocalDate startDate, LocalDate endDate, BigDecimal priceMult) {
        this.timePeriodID = timePeriodID;
        this.hotelID = hotelID;
        this.periodName = periodName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.priceMult = priceMult;
    }

    public Time_period(Integer hotelID, String periodName, LocalDate startDate, LocalDate endDate, BigDecimal priceMult) {
        this.hotelID = hotelID;
        this.periodName = periodName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.priceMult = priceMult;
    }

    

    public Integer getTimePeriodID() {
        return timePeriodID;
    }

    public void setTimePeriodID(Integer timePeriodID) {
        if(timePeriodID == null){
            throw new IllegalArgumentException("TimePeriodID khong duoc de trong");
        }
        this.timePeriodID = timePeriodID;
    }

    public Integer getHotelID() {
        return hotelID;
    }

    public void setHotelID(Integer hotelID) {
        if(hotelID == null){
            throw new IllegalArgumentException("HotelID khong duoc de trong");
        }
        this.hotelID = hotelID;
        
    }

    public String getPeriodName() {
        return periodName;
    }

    public void setPeriodName(String periodName) {
        if(periodName.isEmpty() || periodName.equals("")){
            throw new IllegalArgumentException("PeriodName khong duoc de trong");
        }
        this.periodName = periodName;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        if(startDate == null){
            throw new IllegalArgumentException("Ngay bat dau khong duoc de trong");
        }
        
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        if(endDate == null){
            throw new IllegalArgumentException("Ngay ket thuc khong duoc bo trong");
        }
        
        this.endDate = endDate;
    }

    public BigDecimal getPriceMult() {
        return priceMult;
    }

    public void setPriceMult(BigDecimal priceMult) {
        BigDecimal set;
        
        if(priceMult == null){
            set = new BigDecimal("1.00");
        }else{
            set = priceMult;
        }
        
        BigDecimal max = new BigDecimal("99.99");
        BigDecimal min = new BigDecimal("0.00");
        
        if(set.compareTo(max) > 0 || set.compareTo(min) < 0){
            throw new IllegalArgumentException ("PriceMult lon hon 0 va nho hon 100");
        }
        
        this.priceMult = set;
    }
    
    public boolean kiemTraHopLe(){
        if(startDate == null || endDate == null){
            throw new IllegalArgumentException("Ngay khong duoc de trong");
        }
        
        if(endDate.isBefore(startDate)){
            return false;
        }
        return true;
    }
}
