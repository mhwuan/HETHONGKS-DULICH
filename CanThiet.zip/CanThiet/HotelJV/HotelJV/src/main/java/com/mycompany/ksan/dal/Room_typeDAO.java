package com.mycompany.ksan.dal;

import com.mycompany.ksan.model.Room_type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHUC HIEP
 */
public class Room_typeDAO {
    private final DBContext dbContext;
    
    public Room_typeDAO() {
        this.dbContext = new DBContext();
    }
    
    //Helper
    private Room_type extractRoom_typeFromResultSet(ResultSet rs) throws SQLException {
        Room_type room_type = new Room_type();
        room_type.setRoomTypeID(rs.getInt("RoomTypeID"));
        room_type.setHotelID(rs.getInt("Hotel_ID"));
        
        try {
            room_type.setTypeName(rs.getString("TYPE_NAME"));
            room_type.setCapacity(rs.getInt("Capacity"));
            room_type.setBasePrice(rs.getBigDecimal("BasePrice"));
        } catch (IllegalArgumentException e) {
            System.err.println("Canh bao: Du lieu khong hop le tu DB - " + e.getMessage());
        }
        
        room_type.setDescription(rs.getString("Description"));
        return room_type;
    }
    
    //Insert/Create
    public boolean insertRoom_Type(Room_type room_type) throws SQLException {
        if (room_type == null) {
            throw new IllegalArgumentException("Room_type khong duoc null");
        }
        
        String sql = "Insert into ROOM_TYPE (Hotel_ID, TYPE_NAME, Description, Capacity, BasePrice) Values (?, ?, ?, ?, ?)";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, room_type.getHotelID());
            ps.setString(2, room_type.getTypeName());
            ps.setString(3, room_type.getDescription());
            ps.setInt(4, room_type.getCapacity());
            ps.setBigDecimal(5, room_type.getBasePrice());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi them Room_Type: " + e.getMessage());
            throw e;
        }
    }
    
    //Read by ID
    public Room_type getRoom_TypeByRoom_TypeID(int roomTypeID) throws SQLException {
        String sql = "Select RoomTypeID, Hotel_ID, TYPE_NAME, Description, Capacity, BasePrice From ROOM_TYPE Where RoomTypeID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, roomTypeID);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractRoom_typeFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Loi khi tim Room_Type theo ID: " + e.getMessage());
            throw e;
        }
        return null;
    }
    
    //Read All
    public List<Room_type> getAllRoomType() throws SQLException {
        String sql = "Select * From ROOM_TYPE";
        List<Room_type> roomTypeList = new ArrayList<>();
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                roomTypeList.add(extractRoom_typeFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Loi khi tim tat ca Room_Type: " + e.getMessage());
            throw e;
        }
        return roomTypeList;
    }
    
    //Update
    public boolean updateRoomType(Room_type roomType) throws SQLException {
        if (roomType == null) {
            throw new IllegalArgumentException("Room_type khong duoc null");
        }
        
        String sql = "Update ROOM_TYPE Set Hotel_ID = ?, TYPE_NAME = ?, Description = ?, Capacity = ?, BasePrice = ? Where RoomTypeID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, roomType.getHotelID());
            ps.setString(2, roomType.getTypeName());
            ps.setString(3, roomType.getDescription());
            ps.setInt(4, roomType.getCapacity());
            ps.setBigDecimal(5, roomType.getBasePrice());
            ps.setInt(6, roomType.getRoomTypeID());
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi sua RoomType: " + e.getMessage());
            throw e;
        }
    }
    
    //Delete
    public boolean deleteRoomType(int roomTypeID) throws SQLException {
        String sql = "Delete from ROOM_TYPE Where RoomTypeID = ?";
        
        try (Connection conn = dbContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, roomTypeID);
            
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Loi khi xoa RoomType: " + e.getMessage());
            throw e;
        }
    }
}