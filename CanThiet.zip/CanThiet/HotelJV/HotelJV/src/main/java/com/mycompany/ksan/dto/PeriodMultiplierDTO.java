/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ksan.dto;

import java.math.BigDecimal;

/**
 *
 * @author PHUC HIEP
 */
public class PeriodMultiplierDTO {
    private final Integer periodId; 
    private final BigDecimal multiplier;

    public PeriodMultiplierDTO(Integer periodId, BigDecimal multiplier) {
        this.periodId = periodId;
        this.multiplier = multiplier;
    }

    public Integer getPeriodId() { 
        return periodId; 
    }
    public BigDecimal getMultiplier() { 
        return multiplier; 
    }
}
